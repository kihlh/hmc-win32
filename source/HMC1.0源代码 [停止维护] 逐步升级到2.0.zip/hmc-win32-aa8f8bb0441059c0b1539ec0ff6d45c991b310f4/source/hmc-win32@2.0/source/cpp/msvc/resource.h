//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by hmc_debug.rc

// �¶������һ��Ĭ��ֵ
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
